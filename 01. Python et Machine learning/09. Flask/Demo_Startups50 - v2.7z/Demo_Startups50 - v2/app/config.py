# coding: utf8
import sys

# Modifier la config pour 
# Capturer tous les logs
configuration = {'engine_netflix':'mysql+pymysql://root:Leonne00@localhost/netflix'}